/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/background/background.ts":
/*!**************************************!*\
  !*** ./src/background/background.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   backgroundState: () => (/* binding */ backgroundState)
/* harmony export */ });
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");
/* harmony import */ var _contextMenusOnClicked__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contextMenusOnClicked */ "./src/background/contextMenusOnClicked.ts");
/* harmony import */ var _contextMenuItems__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contextMenuItems */ "./src/background/contextMenuItems.ts");



const backgroundState = {
    currentHighlightId: undefined
};
const backgroundScriptName = "[background.js] ";
// log.info(backgroundScriptName + "started"); // see 'service worker' console from extension
// ------- set side panel behavior
chrome.sidePanel
    // https://developer.chrome.com/docs/extensions/reference/api/sidePanel#method-setPanelBehavior
    .setPanelBehavior({
    openPanelOnActionClick: true, // Defaults to false
})
    .catch((error) => _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].error(error));
// ------------ add menu items:
chrome.runtime.onInstalled.addListener(() => {
    // https://developer.chrome.com/docs/extensions/reference/api/contextMenus
    chrome.contextMenus.create(_contextMenuItems__WEBPACK_IMPORTED_MODULE_2__["default"].highlightAction);
}); // end of chrome.runtime.onInstalled.addListener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
        // (1)
        case "highlightMouseOver":
            // remove a context menu item before adding a new one to ensure safety
            // https://copyprogramming.com/howto/check-if-item-is-already-in-the-context-menu
            try {
                backgroundState.currentHighlightId = message.highlightId;
                chrome.contextMenus.create(_contextMenuItems__WEBPACK_IMPORTED_MODULE_2__["default"].deleteHighlight);
                // chrome.contextMenus.create(contextMenuItems.addNote); // TODO: add this functionality
            }
            catch (error) {
                _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(backgroundScriptName + "Error:");
                _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(error);
            }
            break;
        // (2)
        case "highlightMouseOut":
            try {
                backgroundState.currentHighlightId = undefined;
                // chrome.contextMenus.CreateProperties.id -> string
                // chrome.contextMenus.remove menuItemId: string|number ...
                // thus we need type assertion here
                // https://www.typescriptlang.org/docs/handbook/2/everyday-types.html#type-assertions
                chrome.contextMenus.remove(_contextMenuItems__WEBPACK_IMPORTED_MODULE_2__["default"].deleteHighlight.id);
                // chrome.contextMenus.remove(contextMenuItems.addNote.id as string); // TODO: add this functionality
            }
            catch (error) {
                _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(backgroundScriptName + "Error:");
                _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(error);
            }
            break;
        default:
            _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(backgroundScriptName + "no func for message:");
            _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(message);
    }
});
(0,_contextMenusOnClicked__WEBPACK_IMPORTED_MODULE_1__["default"])();
// ------- send message to content script, when its tab is highlighted (activated)
chrome.tabs.onHighlighted.addListener((highlightInfo) => {
    if (highlightInfo && highlightInfo.tabIds && highlightInfo.tabIds[0]) {
        chrome.tabs.sendMessage(highlightInfo.tabIds[0], {
            action: "tabHighlighted",
        }).catch((error) => {
            _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(error); // log.ts:6 Error: Could not establish connection. Receiving end does not exist. 
        });
    }
});


/***/ }),

/***/ "./src/background/contextMenuItems.ts":
/*!********************************************!*\
  !*** ./src/background/contextMenuItems.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// https://developer.chrome.com/docs/extensions/develop/concepts/match-patterns#examples
// do not show on chrome: , blob: , file: etc.
const showForPages = [
    "https://*/*",
    "https://*/",
    "http://*/*",
    "http://*/",
];
const selectionContext = 'selection';
const allContext = 'all';
const linkContext = 'link';
const contextMenuItems = {
    highlightAction: {
        id: "highlightAction",
        title: "Highlight",
        // https://developer.chrome.com/docs/extensions/reference/api/contextMenus#type-ContextType
        contexts: [selectionContext],
        // see:
        // https://stackoverflow.com/questions/20863005/chrome-extension-context-menu-on-specific-pages
        "documentUrlPatterns": showForPages
    },
    deleteHighlight: {
        id: "deleteHighlight",
        title: "Delete highlight",
        contexts: ["all", "link"] // 'link' is needed in addition to 'all'
    },
    // addNote:
    //     {
    //         id: "addNote",
    //         title: "Add note",
    //         contexts: ["all", "link"] // 'link' is needed in addition to 'all'
    //     },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contextMenuItems);


/***/ }),

/***/ "./src/background/contextMenusOnClicked.ts":
/*!*************************************************!*\
  !*** ./src/background/contextMenusOnClicked.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var _contextMenuItems__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contextMenuItems */ "./src/background/contextMenuItems.ts");
/* harmony import */ var _background__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./background */ "./src/background/background.ts");




const contextMenusOnClicked = () => {
    const funcName = "[contextMenusOnClicked]";
    chrome.contextMenus.onClicked.addListener((
    // OnClickData : Information about the item clicked and the context where the click happened.
    // https://developer.chrome.com/docs/extensions/reference/api/contextMenus#type-OnClickData
    onClickData, 
    // Tab: The details of the tab where the click took place. This parameter is not present for platform apps.
    // https://developer.chrome.com/docs/extensions/reference/api/tabs#type-Tab
    tab //
    ) => {
        if (onClickData && onClickData.menuItemId && onClickData.pageUrl && tab && tab.id && tab.windowId && tab.url) {
            switch (onClickData.menuItemId) {
                case _contextMenuItems__WEBPACK_IMPORTED_MODULE_2__["default"].highlightAction.id:
                    chrome.tabs.sendMessage(tab.id, {
                        action: "highlightSelection",
                        color: _constants__WEBPACK_IMPORTED_MODULE_1__.defaultHighlightColor, // TODO: add 'change color' functionality
                    }).catch((error) => {
                        _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].error(error);
                    });
                    break;
                case _contextMenuItems__WEBPACK_IMPORTED_MODULE_2__["default"].deleteHighlight.id:
                    const message = {
                        action: "removeHighlightById",
                        highlightId: _background__WEBPACK_IMPORTED_MODULE_3__.backgroundState.currentHighlightId,
                    };
                    chrome.tabs.sendMessage(tab.id, message);
                    break;
                // case contextMenuItems.addNote.id:
                //     // https://developer.chrome.com/docs/extensions/reference/api/sidePanel#type-OpenOptions
                //     const sidePanelOpenOptions: chrome.sidePanel.OpenOptions = {
                //         tabId: tab.id,
                //     }
                //     chrome.sidePanel.open(sidePanelOpenOptions)
                //         .then((result) => {
                //             const message: messageType = {
                //                 action: "addNote",
                //                 highlightId: backgroundState.currentHighlightId
                //             }
                //             chrome.runtime.sendMessage(message);
                //         })
                //         .catch((error) => {
                //             log.info(funcName + "chrome.sidePanel.open Error:");
                //             log.info(error);
                //         })
                //     break;
                default:
                    _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].error("no func for " + onClickData.menuItemId);
                    break;
            } // end of switch
        }
        else {
            _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].error("(onClickData && onClickData.menuItemId && onClickData.pageUrl && tab && tab.id && tab.url) is false");
        } // end of if (onClickData && onClickData.menuItemId ...)
    }); // end of chrome.contextMenus.onClicked.addListener ...
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contextMenusOnClicked);


/***/ }),

/***/ "./src/constants.ts":
/*!**************************!*\
  !*** ./src/constants.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaultHighlightColor: () => (/* binding */ defaultHighlightColor),
/* harmony export */   devMode: () => (/* binding */ devMode),
/* harmony export */   markedTextClassName: () => (/* binding */ markedTextClassName)
/* harmony export */ });
const devMode = true; // TODO: change in production
const markedTextClassName = "markedText";
const defaultHighlightColor = "rgba(255,255,85,0.5)";


/***/ }),

/***/ "./src/utils/log.ts":
/*!**************************!*\
  !*** ./src/utils/log.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");

const log = {
    info: (info) => {
        if (_constants__WEBPACK_IMPORTED_MODULE_0__.devMode) {
            console.info(info);
        }
    },
    warn: (warning) => {
        if (_constants__WEBPACK_IMPORTED_MODULE_0__.devMode) {
            console.warn(warning);
        }
    },
    error: (error) => {
        if (_constants__WEBPACK_IMPORTED_MODULE_0__.devMode) {
            console.error(error);
        }
    },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (log);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/background/background.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=background.js.map