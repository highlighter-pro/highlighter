/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/background/addOnMessageListener.ts":
/*!************************************************!*\
  !*** ./src/background/addOnMessageListener.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _contextMenu_contextMenuItems__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contextMenu/contextMenuItems */ "./src/background/contextMenu/contextMenuItems.ts");
/* harmony import */ var _backgroundState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./backgroundState */ "./src/background/backgroundState.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");



const addOnMessageListener = () => {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.action) {
            // (1)
            case "highlightMouseOver":
                // remove a context menu item before adding a new one to ensure safety
                // https://copyprogramming.com/howto/check-if-item-is-already-in-the-context-menu
                try {
                    _backgroundState__WEBPACK_IMPORTED_MODULE_1__["default"].currentHighlightId = message.highlightId;
                    chrome.contextMenus.create(_contextMenu_contextMenuItems__WEBPACK_IMPORTED_MODULE_0__["default"].deleteHighlight);
                    // chrome.contextMenus.create(contextMenuItems.addNote); // TODO: add this functionality
                }
                catch (error) {
                    _constants__WEBPACK_IMPORTED_MODULE_2__.devMode ? console.error(error) : null;
                }
                break;
            // (2)
            case "highlightMouseOut":
                try {
                    _backgroundState__WEBPACK_IMPORTED_MODULE_1__["default"].currentHighlightId = undefined;
                    // chrome.contextMenus.CreateProperties.id -> string
                    // chrome.contextMenus.remove menuItemId: string|number ...
                    // thus we need type assertion here
                    // https://www.typescriptlang.org/docs/handbook/2/everyday-types.html#type-assertions
                    chrome.contextMenus.remove(_contextMenu_contextMenuItems__WEBPACK_IMPORTED_MODULE_0__["default"].deleteHighlight.id);
                    // chrome.contextMenus.remove(contextMenuItems.addNote.id as string); // TODO: add this functionality
                }
                catch (error) {
                    _constants__WEBPACK_IMPORTED_MODULE_2__.devMode ? console.error(error) : null;
                }
                break;
            default:
                console.log(message);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addOnMessageListener);


/***/ }),

/***/ "./src/background/backgroundState.ts":
/*!*******************************************!*\
  !*** ./src/background/backgroundState.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const backgroundState = {
    currentHighlightId: undefined
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (backgroundState);


/***/ }),

/***/ "./src/background/contextMenu/addMenuItems.ts":
/*!****************************************************!*\
  !*** ./src/background/contextMenu/addMenuItems.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _contextMenuItems__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contextMenuItems */ "./src/background/contextMenu/contextMenuItems.ts");

const addMenuItems = () => {
    chrome.runtime.onInstalled.addListener(() => {
        // https://developer.chrome.com/docs/extensions/reference/api/contextMenus
        chrome.contextMenus.create(_contextMenuItems__WEBPACK_IMPORTED_MODULE_0__["default"].highlightAction);
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addMenuItems);


/***/ }),

/***/ "./src/background/contextMenu/contextMenuItems.ts":
/*!********************************************************!*\
  !*** ./src/background/contextMenu/contextMenuItems.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// https://developer.chrome.com/docs/extensions/develop/concepts/match-patterns#examples
// do not show on chrome: , blob: , file: etc.
const showForPages = [
    "https://*/*",
    "https://*/",
    "http://*/*",
    "http://*/",
];
const selectionContext = 'selection';
const allContext = 'all';
const linkContext = 'link';
const contextMenuItems = {
    highlightAction: {
        id: "highlightAction",
        title: "Highlight",
        // https://developer.chrome.com/docs/extensions/reference/api/contextMenus#type-ContextType
        contexts: [selectionContext],
        // see:
        // https://stackoverflow.com/questions/20863005/chrome-extension-context-menu-on-specific-pages
        "documentUrlPatterns": showForPages
    },
    deleteHighlight: {
        id: "deleteHighlight",
        title: "Delete highlight",
        contexts: [allContext, linkContext] // 'link' is needed in addition to 'all'
    },
    // addNote:
    //     {
    //         id: "addNote",
    //         title: "Add note",
    //         contexts: ["all", "link"] // 'link' is needed in addition to 'all'
    //     },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contextMenuItems);


/***/ }),

/***/ "./src/background/contextMenu/contextMenusOnClicked.ts":
/*!*************************************************************!*\
  !*** ./src/background/contextMenu/contextMenusOnClicked.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../constants */ "./src/constants.ts");
/* harmony import */ var _contextMenuItems__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contextMenuItems */ "./src/background/contextMenu/contextMenuItems.ts");
/* harmony import */ var _backgroundState__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../backgroundState */ "./src/background/backgroundState.ts");



const contextMenusOnClicked = () => {
    const funcName = "[contextMenusOnClicked]";
    chrome.contextMenus.onClicked.addListener((
    // OnClickData : Information about the item clicked and the context where the click happened.
    // https://developer.chrome.com/docs/extensions/reference/api/contextMenus#type-OnClickData
    onClickData, 
    // Tab: The details of the tab where the click took place. This parameter is not present for platform apps.
    // https://developer.chrome.com/docs/extensions/reference/api/tabs#type-Tab
    tab //
    ) => {
        if (onClickData && onClickData.menuItemId && onClickData.pageUrl && tab && tab.id && tab.windowId && tab.url) {
            switch (onClickData.menuItemId) {
                // (1) Highlight
                case _contextMenuItems__WEBPACK_IMPORTED_MODULE_1__["default"].highlightAction.id:
                    chrome.tabs.sendMessage(tab.id, {
                        action: "highlightSelection",
                        color: _constants__WEBPACK_IMPORTED_MODULE_0__.defaultHighlightColor, // TODO: add 'change color' functionality
                    }).catch((error) => {
                        console.error(funcName);
                        console.error(error);
                    });
                    break;
                // (2) Delete highlight
                case _contextMenuItems__WEBPACK_IMPORTED_MODULE_1__["default"].deleteHighlight.id:
                    const message = {
                        action: "removeHighlightById",
                        highlightId: _backgroundState__WEBPACK_IMPORTED_MODULE_2__["default"].currentHighlightId,
                    };
                    chrome.tabs.sendMessage(tab.id, message)
                        // .then(r => {
                        //     //
                        // })
                        .catch(error => console.error(error));
                    break;
                // case contextMenuItems.addNote.id:
                //     // https://developer.chrome.com/docs/extensions/reference/api/sidePanel#type-OpenOptions
                //     const sidePanelOpenOptions: chrome.sidePanel.OpenOptions = {
                //         tabId: tab.id,
                //     }
                //     chrome.sidePanel.open(sidePanelOpenOptions)
                //         .then((result) => {
                //             const message: messageType = {
                //                 action: "addNote",
                //                 highlightId: backgroundState.currentHighlightId
                //             }
                //             chrome.runtime.sendMessage(message);
                //         })
                //         .catch((error) => {
                //             log.info(funcName + "chrome.sidePanel.open Error:");
                //             log.info(error);
                //         })
                //     break;
                //
                default:
                    console.log("no func for " + onClickData.menuItemId);
                    break;
            } // end of switch
        }
        else {
            _constants__WEBPACK_IMPORTED_MODULE_0__.devMode ? console.error("(onClickData && onClickData.menuItemId && onClickData.pageUrl && tab && tab.id && tab.url) is false") : null;
        } // end of if (onClickData && onClickData.menuItemId ...)
    }); // end of chrome.contextMenus.onClicked.addListener ...
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contextMenusOnClicked);


/***/ }),

/***/ "./src/background/detectActiveTab.ts":
/*!*******************************************!*\
  !*** ./src/background/detectActiveTab.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _sendMessageToTab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sendMessageToTab */ "./src/background/sendMessageToTab.ts");
// for background script

const detectActiveTab = () => {
    // (1) onActivated
    // https://developer.chrome.com/docs/extensions/reference/api/tabs#event-onActivated
    // Fires when the active tab in a window changes. Note that the tab's URL may not be set at the time this event fired,
    // but you can listen to onUpdated events to be notified when a URL is set.
    // See:
    // ['active' tab VS. 'highlighted' tabs](https://groups.google.com/a/chromium.org/g/chromium-extensions/c/hEDShE5Dwe0):
    // > - An active tab is always highlighted. There is only one active tab per window. Careful, as explained in the
    // > doc, a tab can be active even if it's not in the focused window.
    // > - You can have several highlighted tabs in a same window. But then all highlighted tabs are not active.
    // > Example: select a tab, hold your Shift key, and select another tab. The last tab clicked will become the active
    // > tab for this window, but all tabs between them (including the two limit ones) are now highlighted.
    chrome.tabs.onActivated.addListener((tabActiveInfo) => {
        if (tabActiveInfo && tabActiveInfo.tabId) {
            (0,_sendMessageToTab__WEBPACK_IMPORTED_MODULE_0__["default"])(tabActiveInfo.tabId, "tabActivated");
        }
    });
    // (2) onUpdated
    // https://developer.chrome.com/docs/extensions/reference/api/tabs#event-onUpdated
    // Fired when a tab is updated
    // It seems that the Chrome API does not support a filter (not documented at least)
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/tabs/onUpdated
    chrome.tabs.onUpdated.addListener((tabId, tabChangeInfo //
    ) => {
        if (tabId && tabChangeInfo && tabChangeInfo.status && tabChangeInfo.status === "complete") {
            (0,_sendMessageToTab__WEBPACK_IMPORTED_MODULE_0__["default"])(tabId, "tabUpdated");
        }
    });
    // (*) onHighlighted
    // https://developer.chrome.com/docs/extensions/reference/api/tabs#event-onHighlighted
    // Fired when the highlighted or selected tabs in a window changes
    // chrome.tabs.onHighlighted.addListener((tabHighlightInfo: chrome.tabs.TabHighlightInfo) => {
    //     if (tabHighlightInfo && tabHighlightInfo.tabIds && tabHighlightInfo.tabIds[0]) {
    //         const tabId = tabHighlightInfo.tabIds[0];
    //         //
    //     }
    // });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detectActiveTab);


/***/ }),

/***/ "./src/background/sendMessageToTab.ts":
/*!********************************************!*\
  !*** ./src/background/sendMessageToTab.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var _utils_isWebPage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/isWebPage */ "./src/utils/isWebPage.ts");


const sendMessageToTab = (tabId, messageAction) => {
    chrome.tabs.get(tabId)
        .then((tab) => {
        if (tab && tab.status && tab.status === "complete" && tab.url && (0,_utils_isWebPage__WEBPACK_IMPORTED_MODULE_1__["default"])(tab.url)) {
            chrome.tabs.sendMessage(tabId, {
                action: messageAction,
            }).catch((error) => {
                _constants__WEBPACK_IMPORTED_MODULE_0__.devMode ? console.error(error) : null;
            });
        }
    })
        .catch(error => {
        _constants__WEBPACK_IMPORTED_MODULE_0__.devMode ? console.error(error) : null;
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sendMessageToTab);


/***/ }),

/***/ "./src/background/setSidePanelBehavior.ts":
/*!************************************************!*\
  !*** ./src/background/setSidePanelBehavior.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const setSidePanelBehavior = () => {
    chrome.sidePanel
        // https://developer.chrome.com/docs/extensions/reference/api/sidePanel#method-setPanelBehavior
        .setPanelBehavior({
        openPanelOnActionClick: true, // Defaults to false
    })
        .catch((error) => console.error(error));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (setSidePanelBehavior);


/***/ }),

/***/ "./src/constants.ts":
/*!**************************!*\
  !*** ./src/constants.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaultHighlightColor: () => (/* binding */ defaultHighlightColor),
/* harmony export */   devMode: () => (/* binding */ devMode),
/* harmony export */   markedTextClassName: () => (/* binding */ markedTextClassName)
/* harmony export */ });
const devMode = true; // TODO: change in production
const markedTextClassName = "markedText";
const defaultHighlightColor = "rgba(255,255,85,0.5)";


/***/ }),

/***/ "./src/utils/isWebPage.ts":
/*!********************************!*\
  !*** ./src/utils/isWebPage.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const isWebPage = (urlStr) => {
    try {
        const url = new URL(urlStr);
        return url.protocol === "http:" || url.protocol === "https:";
    }
    catch (error) {
        return false;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (isWebPage);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**************************************!*\
  !*** ./src/background/background.ts ***!
  \**************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _contextMenu_contextMenusOnClicked__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contextMenu/contextMenusOnClicked */ "./src/background/contextMenu/contextMenusOnClicked.ts");
/* harmony import */ var _setSidePanelBehavior__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./setSidePanelBehavior */ "./src/background/setSidePanelBehavior.ts");
/* harmony import */ var _contextMenu_addMenuItems__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contextMenu/addMenuItems */ "./src/background/contextMenu/addMenuItems.ts");
/* harmony import */ var _addOnMessageListener__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./addOnMessageListener */ "./src/background/addOnMessageListener.ts");
/* harmony import */ var _detectActiveTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./detectActiveTab */ "./src/background/detectActiveTab.ts");





// -----  set side panel behavior
(0,_setSidePanelBehavior__WEBPACK_IMPORTED_MODULE_1__["default"])();
// ----- add menu items:
(0,_contextMenu_addMenuItems__WEBPACK_IMPORTED_MODULE_2__["default"])();
// ----- process messages
(0,_addOnMessageListener__WEBPACK_IMPORTED_MODULE_3__["default"])();
// ----- process clicks on menu items
(0,_contextMenu_contextMenusOnClicked__WEBPACK_IMPORTED_MODULE_0__["default"])();
// ----- send message to content script, when its tab is highlighted (activated)
(0,_detectActiveTab__WEBPACK_IMPORTED_MODULE_4__["default"])();

})();

/******/ })()
;
//# sourceMappingURL=background.js.map