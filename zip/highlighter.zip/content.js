/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/range-serializer/dist/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/range-serializer/dist/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deserializeRange = exports.serializeRange = void 0;
const utils_1 = __webpack_require__(/*! ./utils */ "./node_modules/range-serializer/dist/utils.js");
const deserializeRegex = /^([^,]+),([^,\{]+)(\{([^}]+)\})?$/;
const serializeRange = (range, rootNode) => {
    const root = rootNode || (0, utils_1.getRangeDocument)(range).documentElement;
    if (!(0, utils_1.isOrIsAncestorOf)(root, range.commonAncestorContainer)) {
        throw new Error(`serializeRange(): range ${String(range)} is not wholly contained within specified root node ${String(rootNode)}`);
    }
    const serialized = `${(0, utils_1.serializePosition)(range.startContainer, range.startOffset, root)},${(0, utils_1.serializePosition)(range.endContainer, range.endOffset, root)}`;
    return serialized;
};
exports.serializeRange = serializeRange;
const deserializeRange = (serialized, rootNode, doc) => {
    let document;
    let root;
    if (rootNode) {
        document = doc || (0, utils_1.getDocument)(rootNode);
        root = rootNode;
    }
    else {
        document = doc || window.document;
        root = document.documentElement;
    }
    const result = deserializeRegex.exec(serialized);
    const start = (0, utils_1.deserializePosition)(result[1], rootNode, doc);
    const end = (0, utils_1.deserializePosition)(result[2], rootNode, doc);
    const range = document.createRange();
    range.setStart(start.node, start.offset);
    range.setEnd(end.node, end.offset);
    return range;
};
exports.deserializeRange = deserializeRange;


/***/ }),

/***/ "./node_modules/range-serializer/dist/utils.js":
/*!*****************************************************!*\
  !*** ./node_modules/range-serializer/dist/utils.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deserializePosition = exports.serializePosition = exports.getDocument = exports.isOrIsAncestorOf = exports.getRangeDocument = void 0;
const isCharacterDataNode = (node) => {
    const t = node.nodeType;
    return t === 3 || t === 4 || t === 8; // Text, CDataSection or Comment
};
const getRangeDocument = (range) => {
    return (0, exports.getDocument)(range.startContainer);
};
exports.getRangeDocument = getRangeDocument;
const isAncestorOf = (ancestor, descendant, selfIsAncestor) => {
    let n = selfIsAncestor ? descendant : descendant.parentNode;
    while (n) {
        if (n === ancestor) {
            return true;
        }
        else {
            n = n.parentNode;
        }
    }
    return false;
};
const isOrIsAncestorOf = (ancestor, descendant) => {
    return isAncestorOf(ancestor, descendant, true);
};
exports.isOrIsAncestorOf = isOrIsAncestorOf;
function inspectNode(node) {
    if (!node) {
        return "[No node]";
    }
    if (isCharacterDataNode(node)) {
        return "[Broken node]";
    }
    if (node.nodeType === 1) {
        return `<${node.nodeName}>[index:${getNodeIndex(node)},length:${node.childNodes.length}][${String(node).slice(0, 25)}]`;
    }
    return node.nodeName;
}
const getDocument = (node) => {
    if (node.nodeType === 9) {
        return node;
    }
    else if (typeof node.ownerDocument !== "undefined") {
        return node.ownerDocument;
    }
    else if (node.parentNode) {
        return (0, exports.getDocument)(node.parentNode);
    }
    throw new Error("getDocument: no document found for node");
};
exports.getDocument = getDocument;
const getNodeIndex = (node) => {
    let i = 0;
    let currentNode = node;
    while (currentNode.previousSibling !== null) {
        currentNode = currentNode.previousSibling;
        i++;
    }
    return i;
};
const serializePosition = (node, offset, rootNode) => {
    const pathParts = [];
    let n = node;
    const root = rootNode || (0, exports.getDocument)(node).documentElement;
    while (n && n !== root) {
        pathParts.push(getNodeIndex(n));
        n = n.parentNode;
    }
    return `${pathParts.join("/")}:${offset}`;
};
exports.serializePosition = serializePosition;
const deserializePosition = (serializedPosition, rootNode, doc) => {
    const root = rootNode || (doc || document).documentElement;
    const parts = serializedPosition.split(":");
    const nodeIndices = parts[0] ? parts[0].split("/") : [];
    let node = root;
    let i = nodeIndices.length;
    let nodeIndex = 0;
    while (i--) {
        nodeIndex = parseInt(nodeIndices[i], 10);
        if (nodeIndex < node.childNodes.length) {
            node = node.childNodes[nodeIndex];
        }
        else {
            throw new Error(`deserializePosition() failed: node ${inspectNode(node)} has no child with index ${nodeIndex}, ${i}`);
        }
    }
    return {
        node,
        offset: parseInt(parts[1], 10),
    };
};
exports.deserializePosition = deserializePosition;


/***/ }),

/***/ "./src/constants.ts":
/*!**************************!*\
  !*** ./src/constants.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaultHighlightColor: () => (/* binding */ defaultHighlightColor),
/* harmony export */   devMode: () => (/* binding */ devMode),
/* harmony export */   markedTextClassName: () => (/* binding */ markedTextClassName)
/* harmony export */ });
const devMode = true; // TODO: change in production
const markedTextClassName = "markedText";
const defaultHighlightColor = "rgba(255,255,85,0.5)";


/***/ }),

/***/ "./src/content/highlightRange.ts":
/*!***************************************!*\
  !*** ./src/content/highlightRange.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   highlightMouseOutListenerFunc: () => (/* binding */ highlightMouseOutListenerFunc),
/* harmony export */   highlightMouseOverListenerFunc: () => (/* binding */ highlightMouseOverListenerFunc)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");

function highlightMouseOverListenerFunc() {
    const highlightId = this.getAttribute("data-highlightId");
    if (highlightId) {
        const message = {
            action: "highlightMouseOver",
            highlightId: highlightId,
        };
        chrome.runtime.sendMessage(message); // >> for context menu (background script)
    }
}
function highlightMouseOutListenerFunc() {
    const message = { action: "highlightMouseOut", };
    chrome.runtime.sendMessage(message);
}
const highlightRange = (highlightId, range, highlightColor, title) => {
    // const temporaryColor = "#010203"; // > design mode will transform this to background-color: rgb(1, 2, 3);
    // NOTE: spaces are important if using this string in document.querySelectorAll
    const temporaryColor = "rgba(1, 2, 3, 0.01)";
    const selection = window.getSelection() || new Selection();
    selection.removeAllRanges();
    selection.addRange(range);
    // const selectedText = selection.toString();
    document.designMode = "on";
    document.execCommand("HiliteColor", false, temporaryColor);
    selection.removeAllRanges();
    document.designMode = "off";
    // >>> Find all elements marked with temporary color:
    // https://stackoverflow.com/questions/64007739/select-all-elements-with-a-certain-color
    const nodesList = [...document.querySelectorAll('*')] // ! here we have not only <span>s
        .filter(element => getComputedStyle(element).backgroundColor === temporaryColor);
    // >>> change temporary color to highlight color and add required attributes
    nodesList.forEach((element) => {
        // mark as highlighted text by the class name for all highlights
        element.classList.add(_constants__WEBPACK_IMPORTED_MODULE_0__.markedTextClassName);
        // change temporary color to  highlight color
        // https://stackoverflow.com/questions/38454240/using-css-important-with-javascript
        element.style.setProperty("background-color", `${highlightColor || _constants__WEBPACK_IMPORTED_MODULE_0__.defaultHighlightColor}`, "important");
        if (title) {
            element.setAttribute("title", title);
        }
        element.setAttribute("data-highlightId", highlightId);
        // https://developer.mozilla.org/en-US/docs/Web/API/Element/mouseover_event
        element.addEventListener("mouseover", highlightMouseOverListenerFunc);
        // https://developer.mozilla.org/en-US/docs/Web/API/Element/mouseout_event
        element.addEventListener("mouseout", highlightMouseOutListenerFunc);
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (highlightRange);


/***/ }),

/***/ "./src/content/highlightSelection.ts":
/*!*******************************************!*\
  !*** ./src/content/highlightSelection.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var range_serializer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! range-serializer */ "./node_modules/range-serializer/dist/index.js");
/* harmony import */ var _utils_createRandomId__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/createRandomId */ "./src/utils/createRandomId.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _storage_addHighlightToStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../storage/addHighlightToStorage */ "./src/storage/addHighlightToStorage.ts");
/* harmony import */ var _highlightRange__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./highlightRange */ "./src/content/highlightRange.ts");






const highlightSelection = (message) => {
    const selection = window.getSelection();
    if (selection && !selection.isCollapsed) {
        // https://developer.mozilla.org/en-US/docs/Web/API/Selection/toString
        const selectedText = selection.toString();
        let range = selection.getRangeAt(0);
        // >>> do not highlight if range already contains highlighted text
        let doNotHighlight = false;
        const existingHighlights = document.getElementsByClassName(_constants__WEBPACK_IMPORTED_MODULE_0__.markedTextClassName);
        for (const existingHighlight of existingHighlights) {
            if (range.intersectsNode(existingHighlight)) {
                console.log("selected text already highlighted"); // works
                window.alert("Some part of selected text is already highlighted");
                doNotHighlight = true;
                break; // <<< terminates the current loop
            }
        }
        if (!doNotHighlight) {
            const rangeSerialized = (0,range_serializer__WEBPACK_IMPORTED_MODULE_1__.serializeRange)(range);
            const color = message.highlightColor || _constants__WEBPACK_IMPORTED_MODULE_0__.defaultHighlightColor;
            const highlightId = (0,_utils_createRandomId__WEBPACK_IMPORTED_MODULE_2__["default"])();
            const url = new URL(window.location.href);
            const tabUrlAsKey = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_3__["default"])(url);
            const timestamp = Date.now();
            if (tabUrlAsKey) {
                const highlightObj = {
                    id: highlightId,
                    highlightedText: selectedText,
                    color: color,
                    rangeSerialized: rangeSerialized,
                    timestamp: timestamp,
                };
                (0,_storage_addHighlightToStorage__WEBPACK_IMPORTED_MODULE_4__["default"])(tabUrlAsKey, highlightId, highlightObj) // we do it here, not in background script
                    .catch(error => console.log(error));
                (0,_highlightRange__WEBPACK_IMPORTED_MODULE_5__["default"])(highlightId, range, color, selectedText);
            }
        }
    }
    else {
        console.error("(selection && !selection.isCollapsed) is false");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (highlightSelection);


/***/ }),

/***/ "./src/content/markAllHighlightsOnPage.ts":
/*!************************************************!*\
  !*** ./src/content/markAllHighlightsOnPage.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _storage_getHighlightsFromStorage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../storage/getHighlightsFromStorage */ "./src/storage/getHighlightsFromStorage.ts");
/* harmony import */ var range_serializer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! range-serializer */ "./node_modules/range-serializer/dist/index.js");
/* harmony import */ var _highlightRange__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./highlightRange */ "./src/content/highlightRange.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");




const markAllHighlightsOnPage = async () => {
    const funcName = "[markAllHighlightsOnPage] ";
    const urlStr = window.location.href;
    if (urlStr) {
        const key = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_3__["default"])(urlStr);
        if (key) {
            const highlights = await (0,_storage_getHighlightsFromStorage__WEBPACK_IMPORTED_MODULE_0__["default"])(key);
            if (highlights) {
                for (const [highlightId, storedHighlight] of Object.entries(highlights)) {
                    try {
                        const range = (0,range_serializer__WEBPACK_IMPORTED_MODULE_1__.deserializeRange)(storedHighlight.rangeSerialized);
                        (0,_highlightRange__WEBPACK_IMPORTED_MODULE_2__["default"])(highlightId, range, storedHighlight.color, storedHighlight.note);
                    }
                    catch (error) {
                        console.log(funcName + "error restoring highlight " + highlightId + " on " + key + " :");
                        console.log(error);
                    }
                }
            }
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (markAllHighlightsOnPage);


/***/ }),

/***/ "./src/content/processMessagesToContent.ts":
/*!*************************************************!*\
  !*** ./src/content/processMessagesToContent.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _highlightSelection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./highlightSelection */ "./src/content/highlightSelection.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _removeAllHighlights__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./removeAllHighlights */ "./src/content/removeAllHighlights.ts");
/* harmony import */ var _removeHighlightById__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./removeHighlightById */ "./src/content/removeHighlightById.ts");
/* harmony import */ var _markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./markAllHighlightsOnPage */ "./src/content/markAllHighlightsOnPage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");






const processMessagesToContent = () => {
    const funcName = "[processMessagesToContent] ";
    chrome.runtime.onMessage.addListener((message) => {
        // (!!!) you should use chrome.tabs.sendMessage(tabId, message); to send message to content script
        if (message && message.action) {
            switch (message.action) {
                // (1)
                case "highlightSelection":
                    (0,_highlightSelection__WEBPACK_IMPORTED_MODULE_0__["default"])(message);
                    break;
                // (2)
                case "navigateToHighlightId":
                    if (message.highlightId) {
                        const querySelector = `*[data-highlightId='${message.highlightId}']`;
                        // https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
                        // returns the first Element within the document that matches the specified selector, or group of selectors.
                        // If no matches are found, null is returned.
                        const element = document.querySelector(querySelector);
                        if (element) {
                            // https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
                            element.scrollIntoView({
                                behavior: "instant",
                                block: "center",
                                inline: "center"
                            });
                        }
                    }
                    else {
                        _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(funcName + "navigateToHighlightId: (message.highlightId) is false") : null;
                    }
                    break;
                // (3)
                case "removeAllHighlights":
                    const key = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_1__["default"])(window.location.href);
                    if (key) {
                        chrome.storage.local.remove(key)
                            .catch(error => {
                            _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(error) : null;
                        });
                        (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_2__["default"])();
                    }
                    break;
                // (4)
                case "removeHighlightById":
                    if (message.highlightId) {
                        (0,_removeHighlightById__WEBPACK_IMPORTED_MODULE_3__["default"])(message.highlightId); // also removes from storage
                    }
                    else {
                        _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(funcName + "case removeHighlightById: (message.highlightId) is false") : null;
                    }
                    break;
                // (5) this tab is highlighted
                case "tabHighlighted":
                    // update all highlight spans on page
                    // TODO: check if storage changed
                    (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_2__["default"])();
                    (0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_4__["default"])().catch(error => {
                        _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(error) : null;
                    });
                    break;
                // (6) this tab is activated
                // https://developer.chrome.com/docs/extensions/reference/api/tabs#event-onActivated
                // Fires when the active tab in a window changes. Note that the tab's URL may not be set at the time this event fired,
                // but you can listen to onUpdated events to be notified when a URL is set.
                case "tabActivated":
                    // update all highlight spans on page
                    // TODO: check if storage changed
                    (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_2__["default"])();
                    (0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_4__["default"])().catch(error => {
                        _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(error) : null;
                    });
                    break;
                //  (7) tab is updated
                case "tabUpdated":
                    // update all highlight spans on page
                    (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_2__["default"])();
                    (0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_4__["default"])().catch(error => {
                        _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(error) : null;
                    });
                    break;
                // (8) note added
                case "updateHighlights":
                    // update all highlight spans on page
                    // TODO: check if storage changed
                    (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_2__["default"])();
                    (0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_4__["default"])().catch(error => {
                        _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.log(error) : null;
                    });
                    break;
                default:
                    _constants__WEBPACK_IMPORTED_MODULE_5__.devMode ? console.error("no func for message.action: " + message.action) : null;
                    break;
            } // end of switch
        } // enf of if (message && message.action)
    }); // end of chrome.runtime.onMessage.addListener
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (processMessagesToContent);


/***/ }),

/***/ "./src/content/removeAllHighlights.ts":
/*!********************************************!*\
  !*** ./src/content/removeAllHighlights.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var _removeHighlights__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./removeHighlights */ "./src/content/removeHighlights.ts");


const removeAllHighlights = () => {
    // see:
    // https://www.w3.org/TR/2018/REC-selectors-3-20181106/#attribute-selectors
    // [att~=val] Represents an element with the att attribute whose value is a whitespace-separated list of words, one of which is exactly "val".
    // const querySelector = `span[class~='${markedTextClassName}']`; // not only <span>s !
    const querySelector = `*[class~='${_constants__WEBPACK_IMPORTED_MODULE_0__.markedTextClassName}']`;
    // const elementsList = [...document.querySelectorAll<HTMLElement>(querySelector)]; // < array
    (0,_removeHighlights__WEBPACK_IMPORTED_MODULE_1__["default"])(querySelector);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeAllHighlights);


/***/ }),

/***/ "./src/content/removeHighlightById.ts":
/*!********************************************!*\
  !*** ./src/content/removeHighlightById.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _storage_removeHighlightFromStorage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../storage/removeHighlightFromStorage */ "./src/storage/removeHighlightFromStorage.ts");
/* harmony import */ var _removeHighlights__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./removeHighlights */ "./src/content/removeHighlights.ts");



const removeHighlightById = (highlightId) => {
    const funcName = "[removeHighlightById] ";
    if (highlightId) {
        const key = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_0__["default"])(window.location.href);
        if (key) {
            // (1) remove from storage
            (0,_storage_removeHighlightFromStorage__WEBPACK_IMPORTED_MODULE_1__["default"])(key, highlightId)
                .catch(error => console.log(error));
            // (2) remove highlight
            // https://www.w3.org/TR/2018/REC-selectors-3-20181106/#attribute-selectors
            // const querySelector = `span[data-highlightId='${highlightId}']`; // not <span>, we also have <a>
            const querySelector = `*[data-highlightId='${highlightId}']`;
            (0,_removeHighlights__WEBPACK_IMPORTED_MODULE_2__["default"])(querySelector);
        }
        else {
            console.log(funcName + "(key) is false");
        }
    }
    else {
        console.log(funcName + "(highlightId) is false");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeHighlightById);


/***/ }),

/***/ "./src/content/removeHighlights.ts":
/*!*****************************************!*\
  !*** ./src/content/removeHighlights.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _highlightRange__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./highlightRange */ "./src/content/highlightRange.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");


const removeHighlights = (querySelector) => {
    const funcName = "[removeHighlights] ";
    // see:
    // https://stackoverflow.com/questions/18464432/how-to-remove-span-tag-from-the-string
    const elements = document.querySelectorAll(querySelector);
    elements.forEach(element => {
        element.removeEventListener("mouseover", _highlightRange__WEBPACK_IMPORTED_MODULE_0__.highlightMouseOverListenerFunc);
        element.removeEventListener("mouseout", _highlightRange__WEBPACK_IMPORTED_MODULE_0__.highlightMouseOutListenerFunc);
        if (element.tagName === "SPAN" || element.tagName === "span") { // ! upper case
            element.outerHTML = element.innerHTML;
        }
        else if (element.tagName === "A" || element.tagName === "a") { // ! upper case
            element.classList.remove(_constants__WEBPACK_IMPORTED_MODULE_1__.markedTextClassName);
            element.style.removeProperty("background-color"); // we can store this in 'data-old-background-color
            element.removeAttribute("title");
        }
        else {
            console.log(funcName + "this element can not be un-highlighted:");
            console.log(element);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeHighlights);


/***/ }),

/***/ "./src/storage/addHighlightToStorage.ts":
/*!**********************************************!*\
  !*** ./src/storage/addHighlightToStorage.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const addHighlightToStorage = async (keyTabUrl, highlightId, storedHighlightObj) => {
    let storageObjectForTabUrl = await chrome.storage.local.get(keyTabUrl);
    let storedHighlightsWithKeys;
    if (storageObjectForTabUrl && storageObjectForTabUrl[keyTabUrl]) { // if there are stored highlights for this url already
        // valueObj = JSON.parse(data[key]); // not needed, data[key] is an object
        storedHighlightsWithKeys = storageObjectForTabUrl[keyTabUrl];
    }
    else { // no previously stored highlights for this url
        storedHighlightsWithKeys = {};
    }
    storedHighlightsWithKeys[highlightId] = storedHighlightObj;
    const newData = {};
    newData[keyTabUrl] = storedHighlightsWithKeys;
    return chrome.storage.local.set(newData);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addHighlightToStorage);


/***/ }),

/***/ "./src/storage/getHighlightsFromStorage.ts":
/*!*************************************************!*\
  !*** ./src/storage/getHighlightsFromStorage.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getHighlightsFromStorage = async (key) => {
    const storageObjectForTabUrl = await chrome.storage.local.get(key);
    if (storageObjectForTabUrl && storageObjectForTabUrl[key]) {
        return storageObjectForTabUrl[key];
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getHighlightsFromStorage);


/***/ }),

/***/ "./src/storage/removeHighlightFromStorage.ts":
/*!***************************************************!*\
  !*** ./src/storage/removeHighlightFromStorage.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const removeHighlightFromStorage = async (key, highlightId) => {
    const storageObject = await chrome.storage.local.get(key);
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/delete
    delete storageObject[key][highlightId];
    // https://stackoverflow.com/questions/126100/how-to-efficiently-count-the-number-of-keys-properties-of-an-object-in-javascrip
    if (Object.keys(storageObject[key]).length > 0) {
        chrome.storage.local.set(storageObject)
            .catch(error => console.log(error));
    }
    else {
        chrome.storage.local.remove(key)
            .catch(error => console.log(error));
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeHighlightFromStorage);


/***/ }),

/***/ "./src/utils/createRandomId.ts":
/*!*************************************!*\
  !*** ./src/utils/createRandomId.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*
* Creates a pseudorandom alphanumeric lower case 10 character string,
* like: 'nk8pi44rg7'
* */
const createRandomId = () => {
    // ((Math.random()).toString(36).substring(2, 12)).length
    // 10
    return (Math.random()).toString(36).substring(2, 12);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createRandomId);


/***/ }),

/***/ "./src/utils/keyFromUrl.ts":
/*!*********************************!*\
  !*** ./src/utils/keyFromUrl.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*
* Transform full URL to url.origin to (url.hostname) + (url.pathname),
* that will be used as a key for a value in Storage storing all highlights for the given webpage.
* see:
* https://stackoverflow.com/questions/5817505/is-there-any-method-to-get-the-url-without-query-string
* https://stackoverflow.com/a/75884674/1697878
* */
const keyFromUrl = (tabUrl) => {
    const funcName = "[keyFromUrl] ";
    // log.info(funcName + "tabUrl:");
    // log.info(tabUrl);
    let key = "url not recognized";
    if (tabUrl) {
        let url;
        if (typeof tabUrl === "string") { // (tabUrl instanceof String) does not work
            url = new URL(tabUrl);
            key = `${url.hostname}${url.pathname}`;
        }
        else if (tabUrl instanceof URL) {
            url = tabUrl;
            key = `${url.hostname}${url.pathname}`;
        }
        else {
            console.log(funcName + "tabUrl is not String or URL");
        }
        // return (url.hostname).concat(url.pathname);
    }
    else {
        console.log(funcName + "(tabUrl) is false");
    }
    return key;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (keyFromUrl);


/***/ }),

/***/ "./public/manifest.json":
/*!******************************!*\
  !*** ./public/manifest.json ***!
  \******************************/
/***/ ((module) => {

module.exports = JSON.parse('{"name":"highlighter","version":"1.0.4","manifest_version":3,"description":"Highlight text and add notes","options_page":"options.html","background":{"service_worker":"background.js"},"content_scripts":[{"matches":["<all_urls>"],"js":["content.js"]}],"action":{"default_title":"Click to open the side panel"},"icons":{"16":"images/highlighter-green-16.png","128":"images/highlighter-green-128.png"},"side_panel":{"default_path":"sidepanel.html"},"permissions":["sidePanel","contextMenus","tabs","activeTab","storage","unlimitedStorage","downloads"]}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!********************************!*\
  !*** ./src/content/content.ts ***!
  \********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./markAllHighlightsOnPage */ "./src/content/markAllHighlightsOnPage.ts");
/* harmony import */ var _processMessagesToContent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./processMessagesToContent */ "./src/content/processMessagesToContent.ts");
/* harmony import */ var _public_manifest_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../public/manifest.json */ "./public/manifest.json");


// see
// https://stackoverflow.com/questions/49996456/importing-json-file-in-typescript

// const contentScriptName = "[content.ts] ";
console.info(_public_manifest_json__WEBPACK_IMPORTED_MODULE_2__.name + " " + _public_manifest_json__WEBPACK_IMPORTED_MODULE_2__.version + " content script started"); // see 'service worker' console from extension
// ============================  run when markAllHighlightsOnPage() page is opened or changed
// (1) page opened
(0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_0__["default"])() // page opened > works
    // .then(r => {})
    .catch(error => console.log(error));
// (2) storage changed
// const tabUrl = window.location.href;
// if (tabUrl) {
//     chrome.storage.local.onChanged.addListener((changes) => {
//         const tabUrlAsKey = keyFromUrl(tabUrl);
//         if (tabUrlAsKey) {
//             if (changes[tabUrlAsKey]) {
//                 removeAllHighlights();
//                 markAllHighlightsOnPage();
//             }
//         }
//     });
// }
// ===========================     process messages
(0,_processMessagesToContent__WEBPACK_IMPORTED_MODULE_1__["default"])();

})();

/******/ })()
;
//# sourceMappingURL=content.js.map