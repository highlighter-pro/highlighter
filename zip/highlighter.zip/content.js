/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/range-serializer/dist/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/range-serializer/dist/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deserializeRange = exports.serializeRange = void 0;
const utils_1 = __webpack_require__(/*! ./utils */ "./node_modules/range-serializer/dist/utils.js");
const deserializeRegex = /^([^,]+),([^,\{]+)(\{([^}]+)\})?$/;
const serializeRange = (range, rootNode) => {
    const root = rootNode || (0, utils_1.getRangeDocument)(range).documentElement;
    if (!(0, utils_1.isOrIsAncestorOf)(root, range.commonAncestorContainer)) {
        throw new Error(`serializeRange(): range ${String(range)} is not wholly contained within specified root node ${String(rootNode)}`);
    }
    const serialized = `${(0, utils_1.serializePosition)(range.startContainer, range.startOffset, root)},${(0, utils_1.serializePosition)(range.endContainer, range.endOffset, root)}`;
    return serialized;
};
exports.serializeRange = serializeRange;
const deserializeRange = (serialized, rootNode, doc) => {
    let document;
    let root;
    if (rootNode) {
        document = doc || (0, utils_1.getDocument)(rootNode);
        root = rootNode;
    }
    else {
        document = doc || window.document;
        root = document.documentElement;
    }
    const result = deserializeRegex.exec(serialized);
    const start = (0, utils_1.deserializePosition)(result[1], rootNode, doc);
    const end = (0, utils_1.deserializePosition)(result[2], rootNode, doc);
    const range = document.createRange();
    range.setStart(start.node, start.offset);
    range.setEnd(end.node, end.offset);
    return range;
};
exports.deserializeRange = deserializeRange;


/***/ }),

/***/ "./node_modules/range-serializer/dist/utils.js":
/*!*****************************************************!*\
  !*** ./node_modules/range-serializer/dist/utils.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deserializePosition = exports.serializePosition = exports.getDocument = exports.isOrIsAncestorOf = exports.getRangeDocument = void 0;
const isCharacterDataNode = (node) => {
    const t = node.nodeType;
    return t === 3 || t === 4 || t === 8; // Text, CDataSection or Comment
};
const getRangeDocument = (range) => {
    return (0, exports.getDocument)(range.startContainer);
};
exports.getRangeDocument = getRangeDocument;
const isAncestorOf = (ancestor, descendant, selfIsAncestor) => {
    let n = selfIsAncestor ? descendant : descendant.parentNode;
    while (n) {
        if (n === ancestor) {
            return true;
        }
        else {
            n = n.parentNode;
        }
    }
    return false;
};
const isOrIsAncestorOf = (ancestor, descendant) => {
    return isAncestorOf(ancestor, descendant, true);
};
exports.isOrIsAncestorOf = isOrIsAncestorOf;
function inspectNode(node) {
    if (!node) {
        return "[No node]";
    }
    if (isCharacterDataNode(node)) {
        return "[Broken node]";
    }
    if (node.nodeType === 1) {
        return `<${node.nodeName}>[index:${getNodeIndex(node)},length:${node.childNodes.length}][${String(node).slice(0, 25)}]`;
    }
    return node.nodeName;
}
const getDocument = (node) => {
    if (node.nodeType === 9) {
        return node;
    }
    else if (typeof node.ownerDocument !== "undefined") {
        return node.ownerDocument;
    }
    else if (node.parentNode) {
        return (0, exports.getDocument)(node.parentNode);
    }
    throw new Error("getDocument: no document found for node");
};
exports.getDocument = getDocument;
const getNodeIndex = (node) => {
    let i = 0;
    let currentNode = node;
    while (currentNode.previousSibling !== null) {
        currentNode = currentNode.previousSibling;
        i++;
    }
    return i;
};
const serializePosition = (node, offset, rootNode) => {
    const pathParts = [];
    let n = node;
    const root = rootNode || (0, exports.getDocument)(node).documentElement;
    while (n && n !== root) {
        pathParts.push(getNodeIndex(n));
        n = n.parentNode;
    }
    return `${pathParts.join("/")}:${offset}`;
};
exports.serializePosition = serializePosition;
const deserializePosition = (serializedPosition, rootNode, doc) => {
    const root = rootNode || (doc || document).documentElement;
    const parts = serializedPosition.split(":");
    const nodeIndices = parts[0] ? parts[0].split("/") : [];
    let node = root;
    let i = nodeIndices.length;
    let nodeIndex = 0;
    while (i--) {
        nodeIndex = parseInt(nodeIndices[i], 10);
        if (nodeIndex < node.childNodes.length) {
            node = node.childNodes[nodeIndex];
        }
        else {
            throw new Error(`deserializePosition() failed: node ${inspectNode(node)} has no child with index ${nodeIndex}, ${i}`);
        }
    }
    return {
        node,
        offset: parseInt(parts[1], 10),
    };
};
exports.deserializePosition = deserializePosition;


/***/ }),

/***/ "./src/constants.ts":
/*!**************************!*\
  !*** ./src/constants.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaultHighlightColor: () => (/* binding */ defaultHighlightColor),
/* harmony export */   devMode: () => (/* binding */ devMode),
/* harmony export */   markedTextClassName: () => (/* binding */ markedTextClassName)
/* harmony export */ });
const devMode = true; // TODO: change in production
const markedTextClassName = "markedText";
const defaultHighlightColor = "rgba(255,255,85,0.5)";


/***/ }),

/***/ "./src/content/highlightRange.ts":
/*!***************************************!*\
  !*** ./src/content/highlightRange.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   highlightMouseOutListenerFunc: () => (/* binding */ highlightMouseOutListenerFunc),
/* harmony export */   highlightMouseOverListenerFunc: () => (/* binding */ highlightMouseOverListenerFunc)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");

function highlightMouseOverListenerFunc() {
    const highlightId = this.getAttribute("data-highlightId");
    if (highlightId) {
        const message = {
            action: "highlightMouseOver",
            highlightId: highlightId,
        };
        chrome.runtime.sendMessage(message); // >> for context menu (background script)
    }
}
function highlightMouseOutListenerFunc() {
    const message = { action: "highlightMouseOut", };
    chrome.runtime.sendMessage(message);
}
const highlightRange = (highlightId, range, highlightColor, title) => {
    // const temporaryColor = "#010203"; // > design mode will transform this to background-color: rgb(1, 2, 3);
    // NOTE: spaces are important if using this string in document.querySelectorAll
    const temporaryColor = "rgba(1, 2, 3, 0.01)";
    const selection = window.getSelection() || new Selection();
    selection.removeAllRanges();
    selection.addRange(range);
    const selectedText = selection.toString();
    document.designMode = "on";
    document.execCommand("HiliteColor", false, temporaryColor);
    selection.removeAllRanges();
    document.designMode = "off";
    // see:
    // https://stackoverflow.com/questions/62198282/select-element-from-nodelist-by-attribute-value
    // Document: querySelectorAll() method
    // https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelectorAll
    // The Document method querySelectorAll() returns a static (not live) NodeList
    // representing a list of the document's elements that match the specified group of selectors.
    // const nodesList = document.querySelectorAll("span[style='background-color: rgba(1, 2, 3, 0.01);']");
    const styleValue = `background-color: ${temporaryColor};`;
    // document.querySelectorAll(CSS selectors)
    // list of all <span> elements with selected text > not only <span>, design mode does not add <span> if
    // only <code> or <a> element selected, but adds style to this element
    // const querySelector = `span[style='${styleValue}']`;
    // const querySelector = `[style='${styleValue}']`;
    // [att~=val] Represents an element with the att attribute whose value is a whitespace-separated list of words, one of which is exactly "val".
    // const querySelector = `[style~='${styleValue}']`;
    // you can just pass the type of the elements that will be selected (<HTMLElement>), see:
    // https://stackoverflow.com/questions/58773652/ts2339-property-style-does-not-exist-on-type-element
    // const nodesList = document.querySelectorAll(querySelector);
    // const nodesList = document.querySelectorAll<HTMLElement>(querySelector);
    // >>> Find all elements marked with temporary color:
    // https://stackoverflow.com/questions/64007739/select-all-elements-with-a-certain-color
    const nodesList = [...document.querySelectorAll('*')] // ! here we have not only <span>s
        .filter(element => getComputedStyle(element).backgroundColor === temporaryColor);
    // log.info(nodesList);
    let anchorSet = false;
    // >>> change temporary color to highlight color and add required attributes
    nodesList.forEach((element, index, parent) => {
        // TODO: think
        // if (element.tagName !== "span") { // for <a> elements
        //     const span = document.createElement("span");
        //     span.appendChild(span);
        //     element.replaceWith(span);
        // }
        // mark first element of highlighted text for navigation // find the fist node instead
        // if (index === 0 && element.tagName === "span") {
        //     element.setAttribute("id", highlightFirstElementIdPrefix + highlightId);
        // }
        // set an anchor for navigation
        // if (!anchorSet) {
        //     if (!element.id) {
        //         element.setAttribute("id", highlightId);
        //     }
        // }
        // mark as highlighted text by the class name for all highlights
        element.classList.add(_constants__WEBPACK_IMPORTED_MODULE_0__.markedTextClassName);
        // change temporary color to  highlight color
        // element.style.backgroundColor = highlightColor || defaultHighlightColor;
        // element.setAttribute('style', `background-color:${highlightColor || defaultHighlightColor} !important;`);
        // https://stackoverflow.com/questions/38454240/using-css-important-with-javascript
        element.style.setProperty("background-color", `${highlightColor || _constants__WEBPACK_IMPORTED_MODULE_0__.defaultHighlightColor}`, "important");
        // element.setAttribute("title", title || selectedText);
        if (title) {
            element.setAttribute("title", title);
        }
        element.setAttribute("data-highlightId", highlightId);
        // https://developer.mozilla.org/en-US/docs/Web/API/Element/mouseover_event
        element.addEventListener("mouseover", highlightMouseOverListenerFunc);
        // https://developer.mozilla.org/en-US/docs/Web/API/Element/mouseout_event
        element.addEventListener("mouseout", highlightMouseOutListenerFunc);
    });
    // if anchor still not set
    // for example, if there is only <a> element selected with existing id
    // if (!anchorSet && nodesList && nodesList[0] && nodesList[0].parentElement && nodesList[0].parentElement) {
    //     let element: HTMLElement = document.createElement("span");
    //     element.setAttribute("id", highlightId);
    //     nodesList[0].parentElement.insertBefore(element, nodesList[0]);
    // }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (highlightRange);


/***/ }),

/***/ "./src/content/highlightSelection.ts":
/*!*******************************************!*\
  !*** ./src/content/highlightSelection.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");
/* harmony import */ var range_serializer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! range-serializer */ "./node_modules/range-serializer/dist/index.js");
/* harmony import */ var _utils_createRandomId__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/createRandomId */ "./src/utils/createRandomId.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _storage_addHighlightToStorage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../storage/addHighlightToStorage */ "./src/storage/addHighlightToStorage.ts");
/* harmony import */ var _highlightRange__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./highlightRange */ "./src/content/highlightRange.ts");







const highlightSelection = (message) => {
    const selection = window.getSelection();
    if (selection && !selection.isCollapsed) {
        // https://developer.mozilla.org/en-US/docs/Web/API/Selection/toString
        const selectedText = selection.toString();
        let range = selection.getRangeAt(0);
        // >>> do not highlight if range already contains highlighted text
        let doNotHighlight = false;
        const existingHighlights = document.getElementsByClassName(_constants__WEBPACK_IMPORTED_MODULE_0__.markedTextClassName);
        for (const existingHighlight of existingHighlights) {
            if (range.intersectsNode(existingHighlight)) {
                _utils_log__WEBPACK_IMPORTED_MODULE_1__["default"].info("selected text already highlighted"); // works
                window.alert("Some part of selected text is already highlighted");
                doNotHighlight = true;
                break; // <<< terminates the current loop
            }
        }
        if (!doNotHighlight) {
            const rangeSerialized = (0,range_serializer__WEBPACK_IMPORTED_MODULE_2__.serializeRange)(range);
            const color = message.highlightColor || _constants__WEBPACK_IMPORTED_MODULE_0__.defaultHighlightColor;
            const highlightId = (0,_utils_createRandomId__WEBPACK_IMPORTED_MODULE_3__["default"])();
            const url = new URL(window.location.href);
            const tabUrlAsKey = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_4__["default"])(url);
            const timestamp = Date.now();
            if (tabUrlAsKey) {
                const highlightObj = {
                    id: highlightId,
                    highlightedText: selectedText,
                    color: color,
                    rangeSerialized: rangeSerialized,
                    timestamp: timestamp,
                };
                (0,_storage_addHighlightToStorage__WEBPACK_IMPORTED_MODULE_5__["default"])(tabUrlAsKey, highlightId, highlightObj); // we do it here, not in background script
                (0,_highlightRange__WEBPACK_IMPORTED_MODULE_6__["default"])(highlightId, range, color, selectedText);
            }
        }
    }
    else {
        _utils_log__WEBPACK_IMPORTED_MODULE_1__["default"].error("(selection && !selection.isCollapsed) is false");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (highlightSelection);


/***/ }),

/***/ "./src/content/markAllHighlightsOnPage.ts":
/*!************************************************!*\
  !*** ./src/content/markAllHighlightsOnPage.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _storage_getHighlightsFromStorage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../storage/getHighlightsFromStorage */ "./src/storage/getHighlightsFromStorage.ts");
/* harmony import */ var range_serializer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! range-serializer */ "./node_modules/range-serializer/dist/index.js");
/* harmony import */ var _highlightRange__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./highlightRange */ "./src/content/highlightRange.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");





const markAllHighlightsOnPage = async () => {
    const funcName = "[markAllHighlightsOnPage] ";
    const urlStr = window.location.href;
    if (urlStr) {
        const key = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_3__["default"])(urlStr);
        if (key) {
            const highlights = await (0,_storage_getHighlightsFromStorage__WEBPACK_IMPORTED_MODULE_0__["default"])(key);
            if (highlights) {
                for (const [highlightId, storedHighlight] of Object.entries(highlights)) {
                    try {
                        const range = (0,range_serializer__WEBPACK_IMPORTED_MODULE_1__.deserializeRange)(storedHighlight.rangeSerialized);
                        (0,_highlightRange__WEBPACK_IMPORTED_MODULE_2__["default"])(highlightId, range, storedHighlight.color, storedHighlight.note);
                    }
                    catch (error) {
                        _utils_log__WEBPACK_IMPORTED_MODULE_4__["default"].info(funcName + "error restoring highlight " + highlightId + " on " + key + " :");
                        _utils_log__WEBPACK_IMPORTED_MODULE_4__["default"].info(error);
                    }
                }
            }
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (markAllHighlightsOnPage);


/***/ }),

/***/ "./src/content/removeAllHighlights.ts":
/*!********************************************!*\
  !*** ./src/content/removeAllHighlights.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var _removeHighlights__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./removeHighlights */ "./src/content/removeHighlights.ts");


const removeAllHighlights = () => {
    const funcName = "[removeAllHighlights] ";
    // log.info(funcName + "started");
    // see:
    // https://www.w3.org/TR/2018/REC-selectors-3-20181106/#attribute-selectors
    // [att~=val] Represents an element with the att attribute whose value is a whitespace-separated list of words, one of which is exactly "val".
    // const querySelector = `span[class~='${markedTextClassName}']`; // not only <span>s !
    const querySelector = `*[class~='${_constants__WEBPACK_IMPORTED_MODULE_0__.markedTextClassName}']`;
    // const elementsList = [...document.querySelectorAll<HTMLElement>(querySelector)]; // < array
    (0,_removeHighlights__WEBPACK_IMPORTED_MODULE_1__["default"])(querySelector);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeAllHighlights);


/***/ }),

/***/ "./src/content/removeHighlightById.ts":
/*!********************************************!*\
  !*** ./src/content/removeHighlightById.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _storage_removeHighlightFromStorage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../storage/removeHighlightFromStorage */ "./src/storage/removeHighlightFromStorage.ts");
/* harmony import */ var _removeHighlights__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./removeHighlights */ "./src/content/removeHighlights.ts");




const removeHighlightById = (highlightId) => {
    const funcName = "[removeHighlightById] ";
    if (highlightId) {
        const key = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_1__["default"])(window.location.href);
        if (key) {
            // (1) remove from storage
            (0,_storage_removeHighlightFromStorage__WEBPACK_IMPORTED_MODULE_2__["default"])(key, highlightId);
            // (2) remove highlight
            // https://www.w3.org/TR/2018/REC-selectors-3-20181106/#attribute-selectors
            // const querySelector = `span[data-highlightId='${highlightId}']`; // not <span>, we also have <a>
            const querySelector = `*[data-highlightId='${highlightId}']`;
            (0,_removeHighlights__WEBPACK_IMPORTED_MODULE_3__["default"])(querySelector);
        }
        else {
            _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(funcName + "(key) is false");
        }
    }
    else {
        _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(funcName + "(highlightId) is false");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeHighlightById);


/***/ }),

/***/ "./src/content/removeHighlights.ts":
/*!*****************************************!*\
  !*** ./src/content/removeHighlights.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _highlightRange__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./highlightRange */ "./src/content/highlightRange.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");



const removeHighlights = (querySelector) => {
    const funcName = "[removeHighlights] ";
    // see:
    // https://stackoverflow.com/questions/18464432/how-to-remove-span-tag-from-the-string
    const elements = document.querySelectorAll(querySelector);
    elements.forEach(element => {
        element.removeEventListener("mouseover", _highlightRange__WEBPACK_IMPORTED_MODULE_0__.highlightMouseOverListenerFunc);
        element.removeEventListener("mouseout", _highlightRange__WEBPACK_IMPORTED_MODULE_0__.highlightMouseOutListenerFunc);
        if (element.tagName === "SPAN") { // ! upper case
            element.outerHTML = element.innerHTML;
        }
        else if (element.tagName === "A") { // ! upper case
            element.classList.remove(_constants__WEBPACK_IMPORTED_MODULE_1__.markedTextClassName);
            element.style.removeProperty("background-color"); // we can store this in 'data-old-background-color
            element.removeAttribute("title");
        }
        else {
            _utils_log__WEBPACK_IMPORTED_MODULE_2__["default"].info(funcName + "this element can not be un-highlighted:");
            _utils_log__WEBPACK_IMPORTED_MODULE_2__["default"].info(element);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeHighlights);


/***/ }),

/***/ "./src/storage/addHighlightToStorage.ts":
/*!**********************************************!*\
  !*** ./src/storage/addHighlightToStorage.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const addHighlightToStorage = async (keyTabUrl, highlightId, storedHighlightObj) => {
    let storageObjectForTabUrl = await chrome.storage.local.get(keyTabUrl);
    let storedHighlightsWithKeys;
    if (storageObjectForTabUrl && storageObjectForTabUrl[keyTabUrl]) { // if there are stored highlights for this url already
        // valueObj = JSON.parse(data[key]); // not needed, data[key] is an object
        storedHighlightsWithKeys = storageObjectForTabUrl[keyTabUrl];
    }
    else { // no previously stored highlights for this url
        storedHighlightsWithKeys = {};
    }
    storedHighlightsWithKeys[highlightId] = storedHighlightObj;
    const newData = {};
    newData[keyTabUrl] = storedHighlightsWithKeys;
    return chrome.storage.local.set(newData);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addHighlightToStorage);


/***/ }),

/***/ "./src/storage/getHighlightsFromStorage.ts":
/*!*************************************************!*\
  !*** ./src/storage/getHighlightsFromStorage.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getHighlightsFromStorage = async (key) => {
    const storageObjectForTabUrl = await chrome.storage.local.get(key);
    if (storageObjectForTabUrl && storageObjectForTabUrl[key]) {
        return storageObjectForTabUrl[key];
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getHighlightsFromStorage);


/***/ }),

/***/ "./src/storage/removeHighlightFromStorage.ts":
/*!***************************************************!*\
  !*** ./src/storage/removeHighlightFromStorage.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const removeHighlightFromStorage = async (key, highlightId) => {
    const storageObject = await chrome.storage.local.get(key);
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/delete
    delete storageObject[key][highlightId];
    // https://stackoverflow.com/questions/126100/how-to-efficiently-count-the-number-of-keys-properties-of-an-object-in-javascrip
    if (Object.keys(storageObject[key]).length > 0) {
        chrome.storage.local.set(storageObject);
    }
    else {
        chrome.storage.local.remove(key);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (removeHighlightFromStorage);


/***/ }),

/***/ "./src/utils/createRandomId.ts":
/*!*************************************!*\
  !*** ./src/utils/createRandomId.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*
* Creates a pseudorandom alphanumeric lower case 10 character string,
* like: 'nk8pi44rg7'
* */
const createRandomId = () => {
    // ((Math.random()).toString(36).substring(2, 12)).length
    // 10
    return (Math.random()).toString(36).substring(2, 12);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createRandomId);


/***/ }),

/***/ "./src/utils/keyFromUrl.ts":
/*!*********************************!*\
  !*** ./src/utils/keyFromUrl.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _log__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./log */ "./src/utils/log.ts");
/*
* Transform full URL to url.origin to (url.hostname) + (url.pathname),
* that will be used as a key for a value in Storage storing all highlights for the given webpage.
* see:
* https://stackoverflow.com/questions/5817505/is-there-any-method-to-get-the-url-without-query-string
* https://stackoverflow.com/a/75884674/1697878
* */

const keyFromUrl = (tabUrl) => {
    const funcName = "[keyFromUrl] ";
    // log.info(funcName + "tabUrl:");
    // log.info(tabUrl);
    let key = "url not recognized";
    if (tabUrl) {
        let url;
        if (typeof tabUrl === "string") { // (tabUrl instanceof String) does not work
            url = new URL(tabUrl);
            key = `${url.hostname}${url.pathname}`;
        }
        else if (tabUrl instanceof URL) {
            url = tabUrl;
            key = `${url.hostname}${url.pathname}`;
        }
        else {
            _log__WEBPACK_IMPORTED_MODULE_0__["default"].info(funcName + "tabUrl is not String or URL");
        }
        // return (url.hostname).concat(url.pathname);
    }
    else {
        _log__WEBPACK_IMPORTED_MODULE_0__["default"].info(funcName + "(tabUrl) is false");
    }
    // log.info(funcName + "key:");
    // log.info(key);
    return key;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (keyFromUrl);


/***/ }),

/***/ "./src/utils/log.ts":
/*!**************************!*\
  !*** ./src/utils/log.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");

const log = {
    info: (info) => {
        if (_constants__WEBPACK_IMPORTED_MODULE_0__.devMode) {
            console.info(info);
        }
    },
    warn: (warning) => {
        if (_constants__WEBPACK_IMPORTED_MODULE_0__.devMode) {
            console.warn(warning);
        }
    },
    error: (error) => {
        if (_constants__WEBPACK_IMPORTED_MODULE_0__.devMode) {
            console.error(error);
        }
    },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (log);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!********************************!*\
  !*** ./src/content/content.ts ***!
  \********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_log__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/log */ "./src/utils/log.ts");
/* harmony import */ var _utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/keyFromUrl */ "./src/utils/keyFromUrl.ts");
/* harmony import */ var _markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./markAllHighlightsOnPage */ "./src/content/markAllHighlightsOnPage.ts");
/* harmony import */ var _removeAllHighlights__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./removeAllHighlights */ "./src/content/removeAllHighlights.ts");
/* harmony import */ var _removeHighlightById__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./removeHighlightById */ "./src/content/removeHighlightById.ts");
/* harmony import */ var _highlightSelection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./highlightSelection */ "./src/content/highlightSelection.ts");






const contentScriptName = "[content.ts] ";
_utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(contentScriptName + "started"); // see 'service worker' console from extension
// ============================  run when markAllHighlightsOnPage() page is opened or changed
// (1) page opened
(0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_2__["default"])(); // page opened > works
// (2) storage changed
// const tabUrl = window.location.href;
// if (tabUrl) {
//     chrome.storage.local.onChanged.addListener((changes) => {
//         const tabUrlAsKey = keyFromUrl(tabUrl);
//         if (tabUrlAsKey) {
//             if (changes[tabUrlAsKey]) {
//                 removeAllHighlights();
//                 markAllHighlightsOnPage();
//             }
//         }
//     });
// }
// ===========================     process messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // (!!!) you should use chrome.tabs.sendMessage(tabId, message); to send message to content script
    if (message && message.action) {
        switch (message.action) {
            // (1)
            case "highlightSelection":
                (0,_highlightSelection__WEBPACK_IMPORTED_MODULE_5__["default"])(message);
                break;
            // (2)
            case "navigateToHighlightId":
                if (message.highlightId) {
                    const querySelector = `*[data-highlightId='${message.highlightId}']`;
                    // https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
                    // returns the first Element within the document that matches the specified selector, or group of selectors.
                    // If no matches are found, null is returned.
                    const element = document.querySelector(querySelector);
                    if (element) {
                        // https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
                        element.scrollIntoView({
                            behavior: "instant",
                            block: "center",
                            inline: "center"
                        });
                    }
                }
                else {
                    _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].info(contentScriptName + "navigateToHighlightId: (message.highlightId) is false");
                }
                break;
            // (3)
            case "removeAllHighlights":
                const key = (0,_utils_keyFromUrl__WEBPACK_IMPORTED_MODULE_1__["default"])(window.location.href);
                if (key) {
                    chrome.storage.local.remove(key);
                    (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_3__["default"])();
                }
                break;
            // (4)
            case "removeHighlightById":
                if (message.highlightId) {
                    (0,_removeHighlightById__WEBPACK_IMPORTED_MODULE_4__["default"])(message.highlightId); // also removes from storage
                }
                else {
                    console.log(contentScriptName + "case removeHighlightById: (message.highlightId) is false");
                }
                break;
            // (5) this tab is highlighted (activated)
            case "tabHighlighted":
                // update all highlight spans on page
                // TODO: check if storage changed
                (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_3__["default"])();
                (0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_2__["default"])();
                break;
            // (6) note added
            case "updateHighlights":
                // update all highlight spans on page
                // TODO: check if storage changed
                (0,_removeAllHighlights__WEBPACK_IMPORTED_MODULE_3__["default"])();
                (0,_markAllHighlightsOnPage__WEBPACK_IMPORTED_MODULE_2__["default"])();
                break;
            default:
                _utils_log__WEBPACK_IMPORTED_MODULE_0__["default"].error("no func for message.action: " + message.action);
                break;
        } // end of switch
    } // enf of if (message && message.action)
}); // end of chrome.runtime.onMessage.addListener

})();

/******/ })()
;
//# sourceMappingURL=content.js.map